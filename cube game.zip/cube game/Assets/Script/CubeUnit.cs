using UnityEngine;

public class CubeUnit : MonoBehaviour
{
    public GridCell CurrentCell;
    public CubeUnit OccupiedCube;
    public bool IsOccupied => OccupiedCube != null;
}