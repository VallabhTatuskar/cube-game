using UnityEngine;

[CreateAssetMenu(menuName = "Cube Type")]
public class CubeType : ScriptableObject
{
    public string cubeName;
    public Material cubeMaterial;
}