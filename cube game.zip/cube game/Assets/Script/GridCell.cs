using UnityEngine;

public class GridCell : MonoBehaviour
{
    [SerializeField] private Renderer meshRenderer;
    [SerializeField] private Material normalMaterial;
    [SerializeField] private Material selectedMaterial;

    public Vector2Int GridPosition { get; set; }

    public CubeUnit OccupiedCube;
    public bool IsOccupied => OccupiedCube != null;

    private void Awake()
    {
        meshRenderer = GetComponent<Renderer>();
    }

    public void Select()
    {
        meshRenderer.material = selectedMaterial;
    }

    public void Deselect()
    {
        meshRenderer.material = normalMaterial;
    }
}