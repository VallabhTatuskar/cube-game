using System.Collections.Generic;
using UnityEngine;

public class GridManager : MonoBehaviour
{
    private List<CubeUnit> spawnedCubes = new List<CubeUnit>();
    [SerializeField] private CubeType[] cubeTypes;

    private int currentCubeTypeIndex = 0;
    [Header("Grid Settings")]
    [SerializeField] private GameObject cubePrefab;
    private GridCell[,] grid;
    private GridCell selectedCell;
    [SerializeField] private int width = 5;
    [SerializeField] private int height = 5;
    [SerializeField] private float cellSize = 1f;

    [Header("References")]
    [SerializeField] private GameObject cellPrefab;

    private void Start()
    {
        GenerateGrid();
    }

    private void Update()
    {
        float scroll = Input.mouseScrollDelta.y;
        
        if (scroll > 0)
        {
            currentCubeTypeIndex++;
        }
        else if (scroll < 0)
        {
            currentCubeTypeIndex--;
        }

        if (currentCubeTypeIndex >= cubeTypes.Length)
        {
            currentCubeTypeIndex = 0;
        }

        if (currentCubeTypeIndex < 0)
        {
            currentCubeTypeIndex = cubeTypes.Length - 1;
        }

        SelectCell();

        if (Input.GetKeyDown(KeyCode.Space))
        {
            SpawnCube();
        }

        if (Input.GetKeyDown(KeyCode.W))
            MoveAllCubes(Vector2Int.up);

        if (Input.GetKeyDown(KeyCode.S))
            MoveAllCubes(Vector2Int.down);

        if (Input.GetKeyDown(KeyCode.A))
            MoveAllCubes(Vector2Int.left);

        if (Input.GetKeyDown(KeyCode.D))
            MoveAllCubes(Vector2Int.right);
        
    }

    private void SpawnCube()
    {
        if (selectedCell == null)
            return;

        if (selectedCell.IsOccupied)
            return;

        Vector3 spawnPosition = selectedCell.transform.position + Vector3.up * 0.45f;

        GameObject cube = Instantiate(cubePrefab, spawnPosition, Quaternion.identity);

        Renderer renderer = cube.GetComponent<Renderer>();
        renderer.material = cubeTypes[currentCubeTypeIndex].cubeMaterial;

        CubeUnit cubeUnit = cube.GetComponent<CubeUnit>();

        cubeUnit.CurrentCell = selectedCell;
        selectedCell.OccupiedCube = cubeUnit;

        spawnedCubes.Add(cubeUnit);
    }

    private void SelectCell()
    {
        if (!Input.GetMouseButtonDown(0))
            return;

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        if (Physics.Raycast(ray, out RaycastHit hit))
        {
            GridCell cell = hit.collider.GetComponent<GridCell>();

            if (cell == null)
                return;

            if (selectedCell != null)
                selectedCell.Deselect();

            selectedCell = cell;
            selectedCell.Select();
        }
    }

    private void GenerateGrid()
    {
        grid = new GridCell[width, height];

        for (int x = 0; x < width; x++)
        {
            for (int z = 0; z < height; z++)
            {
                Vector3 position = new Vector3(x, 0, z);

                GameObject obj = Instantiate(cellPrefab, position, Quaternion.identity, transform);

                GridCell cell = obj.GetComponent<GridCell>();

                cell.GridPosition = new Vector2Int(x, z);

                grid[x, z] = cell;
            }
        }
    }

    private bool IsInsideGrid(Vector2Int pos)
    {
        return pos.x >= 0 && pos.x < width && pos.y >= 0 && pos.y < height;
    }
    private void MoveAllCubes(Vector2Int direction)
    {
        foreach (CubeUnit cube in spawnedCubes)
        {
            Vector2Int currentPos = cube.CurrentCell.GridPosition;
            Vector2Int newPos = currentPos + direction;

        // Ignore this cube if it would leave the grid
            if (!IsInsideGrid(newPos))
                continue;

            GridCell newCell = grid[newPos.x, newPos.y];

        // Ignore if another cube is already there
            if (newCell.IsOccupied)
                continue;

        // Free the old cell
            cube.CurrentCell.OccupiedCube = null;

        // Occupy the new cell
            newCell.OccupiedCube = cube;
            cube.CurrentCell = newCell;

        // Move the GameObject
            cube.transform.position = newCell.transform.position + Vector3.up * 0.45f;
        }
    }
}