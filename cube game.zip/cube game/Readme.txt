Grid Mechanics Technical Assessment

Developer:
Vallabh Tatuskar


Project Overview:
This project implements an inspector-driven grid system in Unity. The player can select grid cells, spawn cubes with different ScriptableObject-defined color variants, and move all spawned cubes simultaneously while respecting grid boundaries.

Features:
- Inspector-configurable grid size (Width & Height)
- Grid cell selection using the left mouse button
- Visual highlight for the selected cell
- Spawn cubes using the Space key
- Only one cube can occupy a grid cell
- Mouse scroll wheel cycles through different cube types
- Simultaneous movement of all cubes using W, A, S, and D
- Boundary constraints prevent cubes from leaving the grid

Controls:
Left Mouse Button  - Select Grid Cell
Mouse Scroll Wheel - Change Cube Type
Space              - Spawn Cube
W / A / S / D      - Move All Cubes

Third-Party Assets / Packages:
None

Assumptions:
- Four cube types (Red, Blue, Green, and Yellow) are used to represent different cube variants.
- Cube variants differ only by their material/color.
- One cube is allowed per grid cell.

Known Limitations:
- Cube movement is instantaneous (no movement animation).
- No UI is included to display the currently selected cube type.

Future Improvements:
- Add smooth movement animations.
- Add a UI indicator for the selected cube type.
- Add sound effects and visual feedback.
- Implement save/load functionality.

Thank you for reviewing my submission.